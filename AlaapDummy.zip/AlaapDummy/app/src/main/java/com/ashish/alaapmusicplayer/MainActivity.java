package com.ashish.alaapmusicplayer;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ashish.alaapmusicplayer.UpdateCheck.VersionChecker;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.sothree.slidinguppanel.SlidingUpPanelLayout;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

//5132234413676201121 play store adccount id
//Created on date 26/10/2019 by Ashish..
public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getName();


    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    public static final String Broadcast_PLAY_NEW_AUDIO = "com.ashish.alaapmusicplayer.PlayNewAudio";
    private MediaPlayerService player;
    boolean serviceBound = false;
    ArrayList<Audio> audioList;
    ImageView collapsingImageView;
    int imageIndex = 0;
    Button pause,next,previous,loop;
    SlidingUpPanelLayout slidingUpPanelLayout;
    ImageView imageView;
    TextView songNameText,MaxSongLength,elapsedTime;
    private int audioIndex = -1;
    private Audio activeAudio;
    Thread t2;
    int totalDuration,currentPosition;
    boolean isPlaying;
    SeekBar sb;
    String currentVersion, latestVersion;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES); //For night mode theme
        setContentView(R.layout.activity_two);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);


        isPlaying=false;
        songNameText = (TextView) findViewById(R.id.txtSongLabel);
        sb=(SeekBar)findViewById(R.id.seekBar);
        MaxSongLength = (TextView) findViewById(R.id.totalTime);
        elapsedTime = (TextView) findViewById(R.id.elapsedTime);
        loop = (Button)findViewById(R.id.loop);

        pause = (Button)findViewById(R.id.pause);
        imageView=findViewById(R.id.album);
        pause.setBackgroundResource(R.drawable.ic_play_arrow_black_24dp);
        previous = (Button)findViewById(R.id.previous);
        next = (Button)findViewById(R.id.next);
        slidingUpPanelLayout = (SlidingUpPanelLayout) findViewById(R.id.sliding_layout);
      //  slidingUpPanelLayout.setPanelState(SlidingUpPanelLayout.PanelState.HIDDEN);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle params = new Bundle();
        params.putString("open_time", String.valueOf(System.currentTimeMillis()));
        mFirebaseAnalytics.logEvent("app_open_time", params);




        //fcm
//        FirebaseInstanceId.getInstance().getInstanceId()
//                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
//                    @Override
//                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
//                        if (!task.isSuccessful()) {
//                            //To do//
//                            return;
//                        }
//
//                        // Get the Instance ID token//
//                        String token = task.getResult().getToken();
//                        String msg = getString(R.string.fcm_token, token);
//                        Log.d(TAG, msg);
//
//                    }
//                });

        loadAudioList();

       // new MyAsyncTask().execute();


        final Handler handler = new Handler();
        Runnable runnable = new Runnable() {

            public void run() {

                int index = -1;
                try{
                    index=player.audioIndex;
                    Log.d(TAG,"index"+index);   
                    
                }catch (NullPointerException e){}
               
                if(index>=0)
                {
                    Log.d(TAG,"IndexG");
                    sb.setMax(player.mediaPlayer.getDuration());
                    totalDuration=player.mediaPlayer.getDuration();
                    String time = String.format("%02d:%02d",
                            TimeUnit.MILLISECONDS.toMinutes(totalDuration),
                            TimeUnit.MILLISECONDS.toSeconds(totalDuration) -
                                    TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(totalDuration)));
                    MaxSongLength.setText(time);
                    sb.setProgress(player.mediaPlayer.getCurrentPosition());
                    ShowAlbum();
                    if (player.CheckStatus()){

                        pause.setBackgroundResource(R.drawable.pause);

                    }else {
                        pause.setBackgroundResource(R.drawable.ic_play_arrow_black_24dp);

                    }
                }



                handler.postDelayed(this, 1000);  //for interval...
            }
        };
        handler.postDelayed(runnable, 1000);


        sb.getProgressDrawable().setColorFilter(getResources().getColor(R.color.colorPrimary), PorterDuff.Mode.MULTIPLY);
        sb.getThumb().setColorFilter(getResources().getColor(R.color.red), PorterDuff.Mode.SRC_IN);


        sb.setOnSeekBarChangeListener(new
                                              SeekBar.OnSeekBarChangeListener() {
                                                  @Override
                                                  public void onProgressChanged(SeekBar seekBar, int i,
                                                                                boolean b) {
                                                        currentPosition=player.mediaPlayer.getCurrentPosition();
                                                      String time = String.format("%02d:%02d",
                                                              TimeUnit.MILLISECONDS.toMinutes(currentPosition),
                                                              TimeUnit.MILLISECONDS.toSeconds(currentPosition) -
                                                                      TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(currentPosition)));
                                                      elapsedTime.setText(time);
                                                  }
                                                  @Override
                                                  public void onStartTrackingTouch(SeekBar seekBar) {


                                                  }
                                                  @Override
                                                  public void onStopTrackingTouch(SeekBar seekBar) {
                                                      player.mediaPlayer.seekTo(seekBar.getProgress());


                                                  }
                                              });





        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (player.CheckStatus()){
                    player.pauseMedia();
                    pause.setBackgroundResource(R.drawable.ic_play_arrow_black_24dp);
                    player.StopNotify();

                }else {
                    player.resumeMedia();
                    pause.setBackgroundResource(R.drawable.pause);
                    player.StartNotify();
                }
            }
        });

        loop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (player.CheckLooping())
                {
                    player.DisableLoop();
                   // loop.setBackgroundColor(Color.WHITE);
                    loop.setBackgroundResource(R.drawable.ic_loop_black_24dp);


                }else
                {
                    player.EnableLoop();
                  //  loop.setBackgroundColor(Color.RED);

                    loop.setBackgroundResource(R.drawable.ic_autorenew_black_24dp);

                }


            }
        });

        next.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
             pause.setBackgroundResource(R.drawable.pause);
             player.skipToNext();
             player.StartNotify();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    sb.setMin(0);
                }
                ShowAlbum();


            }
        });

        previous.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
            pause.setBackgroundResource(R.drawable.pause);
            player.skipToPrevious();
            player.StartNotify();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    sb.setMin(0);
                }
                ShowAlbum();

            }
        });


        //SidingUpLayout
        slidingUpPanelLayout.addPanelSlideListener(new SlidingUpPanelLayout.PanelSlideListener() {
            @Override
            public void onPanelSlide(View panel, float slideOffset) {



            }

            @Override
            public void onPanelStateChanged(View panel, SlidingUpPanelLayout.PanelState previousState, SlidingUpPanelLayout.PanelState newState) {

                //  Toast.makeText(getApplicationContext(),newState.name().toString(),Toast.LENGTH_SHORT).show();
                if(newState.name().toString().equalsIgnoreCase("Collapsed")){

                    //action when collapsed





                }else if(newState.name().equalsIgnoreCase("Expanded")){

                    //action when expanded



                }

            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
       // slidingUpPanelLayout.setPanelState(SlidingUpPanelLayout.PanelState.COLLAPSED);
        try {
            //Load data from SharedPreferences
            StorageUtil storage = new StorageUtil(getApplicationContext());
            audioIndex = storage.loadAudioIndex();
            Log.d(TAG,"onRes_audioIndex"+audioIndex);
            if (audioIndex != -1) {
                //index is in a valid range
                activeAudio = audioList.get(audioIndex);

               // playAudio(audioIndex);
              //  sb.setMax(player.mediaPlayer.getDuration());
              //  totalDuration=player.mediaPlayer.getDuration();
//                String time = String.format("%02d:%02d",
//                        TimeUnit.MILLISECONDS.toMinutes(totalDuration),
//                        TimeUnit.MILLISECONDS.toSeconds(totalDuration) -
//                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(totalDuration)));
//                MaxSongLength.setText(time);
//                sb.setProgress(player.mediaPlayer.getCurrentPosition());
//                songNameText.setText(activeAudio.getTitle());
//                songNameText.setSelected(true);


            } else {
            }
        } catch (NullPointerException e) {
        }


    }

    @Override
    protected void onRestart() {
        super.onRestart();

    }

    private void loadAudioList() {
        loadAudio();
        initRecyclerView();

        }






    private void initRecyclerView() {
        if (audioList != null && audioList.size() > 0) {
            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
            RecyclerView_Adapter adapter = new RecyclerView_Adapter(audioList, getApplication());
            recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(),
                    DividerItemDecoration.VERTICAL));
            recyclerView.setAdapter(adapter);
            recyclerView.setHasFixedSize(true);                                    //added
            recyclerView.setLayoutManager(new LinearLayoutManager(this));//added
            recyclerView.setItemViewCacheSize(20);//added
            recyclerView.setDrawingCacheEnabled(true);//added
            recyclerView.setDrawingCacheQuality(View.DRAWING_CACHE_QUALITY_HIGH);//added
            recyclerView.setNestedScrollingEnabled(false); //added
            recyclerView.addOnItemTouchListener(new CustomTouchListener(this, new onItemClickListener() {
                @Override
                public void onClick(View view, int index) {
                    playAudio(index);
                    pause.setBackgroundResource(R.drawable.pause);
                    slidingUpPanelLayout.setPanelState(SlidingUpPanelLayout.PanelState.COLLAPSED);



                }
            }));


        }


    }

    private void loadCollapsingImage(int i) {
        TypedArray array = getResources().obtainTypedArray(R.array.images);
       // collapsingImageView.setImageDrawable(array.getDrawable(i));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.rating) {

            try{
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id="+getPackageName())));
            }
            catch (ActivityNotFoundException e){
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+getPackageName())));
            }
            return true;
        }

        if (id == R.id.update) {
            VersionChecker versionChecker = new VersionChecker();
            try {
                String latestVersion = versionChecker.execute().get();
                String versionName = BuildConfig.VERSION_NAME.replace("-DEBUG","");
                if (latestVersion != null && !latestVersion.isEmpty()) {
                    if (!latestVersion.matches(versionName)) {
                        showDialogToSendToPlayStore();
                    }else{
                        Toast.makeText(MainActivity.this,"Alredy on latest version",Toast.LENGTH_LONG).show();
                    }
                }
                Log.d("update", "Current version " + Float.valueOf(versionName) + ", Playstore version " + Float.valueOf(latestVersion));

            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void showDialogToSendToPlayStore(){


        AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
        dialog.setCancelable(false);
        dialog.setIcon(R.drawable.splash_cent);
        dialog.setTitle("UPGRADE TO LATEST VERSION");
        dialog.setMessage("\n\nTo enjoy the ne features update to latest version" );
        dialog.setPositiveButton("UPDATE ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                //Action for "update".
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" +"com.ashish.alaapmusicplayer")));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" +"com.ashish.alaapmusicplayer")));
                }
            }
        })
                .setNegativeButton("Cancel ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Action for "Cancel".
                        Toast.makeText(MainActivity.this,"Pease update to latest version",Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }
                });

        final AlertDialog alert = dialog.create();
        alert.show();
    }


    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putBoolean("serviceStatus", serviceBound);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        serviceBound = savedInstanceState.getBoolean("serviceStatus");
    }

    //Binding this Client to the AudioPlayer Service
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            MediaPlayerService.LocalBinder binder = (MediaPlayerService.LocalBinder) service;
            player = binder.getService();
            serviceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            serviceBound = false;
        }
    };

    private void playAudio(int audioIndex) {
        //Check is service is active
        if (!serviceBound) {
            //Store Serializable audioList to SharedPreferences
            StorageUtil storage = new StorageUtil(getApplicationContext());
            storage.storeAudio(audioList);
            storage.storeAudioIndex(audioIndex);

            Intent playerIntent = new Intent(this, MediaPlayerService.class);
            startService(playerIntent);
            bindService(playerIntent, serviceConnection, Context.BIND_AUTO_CREATE);
        } else {
            //Store the new audioIndex to SharedPreferences
            StorageUtil storage = new StorageUtil(getApplicationContext());
            storage.storeAudioIndex(audioIndex);

            //Service is active
            //Send a broadcast to the service -> PLAY_NEW_AUDIO
            Intent broadcastIntent = new Intent(Broadcast_PLAY_NEW_AUDIO);
            sendBroadcast(broadcastIntent);

            //check for looping
            player.DisableLoop();
            // loop.setBackgroundColor(Color.WHITE);
            loop.setBackgroundResource(R.drawable.ic_loop_black_24dp);



        }


//        try
//        {
//                int index=player.audioIndex;
//                Log.d(TAG,"index"+index);
//               if(index>=0)
//               {
//                Log.d(TAG,"IndexG");
//          //      ShowAlbum();
//               }
//        }catch (Exception e){}


    }


    private void loadAudio() {
        ContentResolver contentResolver = getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String selection = MediaStore.Audio.Media.IS_MUSIC + "!= 0";
        String sortOrder = MediaStore.Audio.Media.TITLE + " ASC";
        Cursor cursor = contentResolver.query(uri, null, selection, null, sortOrder);
        if (cursor != null && cursor.getCount() > 0) {
            audioList = new ArrayList<>();
            while (cursor.moveToNext()) {
                String data = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                String title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                String album = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM));
                String artist = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
                // Save to audioList
                audioList.add(new Audio(data, title, album, artist));
            }
        }
        cursor.close();
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serviceBound) {
            unbindService(serviceConnection);
            //service is active
            player.stopSelf();
            player.StopNotify();
        }
    }



    @Override
    public void onBackPressed() {
        Log.d("onBackPressed", "onBackPressed Called");
        moveTaskToBack(true);
    }



    @SuppressLint("ResourceType")
    public void ShowAlbum()
    {
        Log.d(TAG,"showAlb");
        Bitmap albumArt;
        MediaMetadataRetriever meta = new MediaMetadataRetriever();
       // StorageUtil storage = new StorageUtil(getApplicationContext());
        audioIndex = player.audioIndex;
        activeAudio =player.activeAudio;
        if (audioIndex != -1 && audioIndex < audioList.size()) {
            //index is in a valid range
            activeAudio = audioList.get(audioIndex);
        }
     try {
         Log.d(TAG,"Image");
        meta.setDataSource(activeAudio.getData());
        byte imgdata[] = meta.getEmbeddedPicture();
       albumArt = BitmapFactory.decodeByteArray(imgdata, 0, imgdata.length);
       imageView.setImageBitmap(albumArt);
       songNameText.setText(activeAudio.getTitle());
       songNameText.setSelected(true);
     } catch (Exception e) {
        albumArt = BitmapFactory.decodeResource(getResources(), R.drawable.cover_art);
        imageView.setImageResource(R.drawable.unsplash);
     }
//        slidingUpPanelLayout.setBackgroundResource(getResources().getColor(R.color.colorAccent));



    }


}