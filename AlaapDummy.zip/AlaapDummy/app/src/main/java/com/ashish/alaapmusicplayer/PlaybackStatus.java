package com.ashish.alaapmusicplayer;

public enum PlaybackStatus {
    PLAYING,
    PAUSED
}