package com.ashish.alaapmusicplayer;

import android.view.View;

public interface onItemClickListener {
    void onClick(View view, int index);
}